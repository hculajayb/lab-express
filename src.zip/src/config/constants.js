export const GENDERDATA = [
  {
    value: 1,
    name: "Masculino",
  },
  {
    value: 2,
    name: "Femenino",
  },
  {
    value: 3,
    name: "Otro",
  },
];
