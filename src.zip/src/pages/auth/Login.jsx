import { Col, Row } from "react-bootstrap";
import Form from "react-bootstrap/Form";
import "../../styles/auth/index.css";

export const Login = () => {
  return (
    <div className="container">
      <Row className="align-items-center main">
        <section>
          <h1 className="text-center fw-bold">Iniciar Sesión</h1>
          <form action="Controlador">
            <label>Nombre de Usuario:</label>
            <input
              className="form-control"
              type="text"
              name="txtNombre_Usuario"
            />
            <label>Contraseña:</label>
            <input
              type="password"
              className="form-control"
              name="txtContrasenia"
            />
            <Form.Text id="passwordHelpBlock" muted>
              Su contraseña debe tener entre 8 y 20 caracteres, contener letras
              y números y no debe contener espacios, caracteres especiales ni
              emojis.
            </Form.Text>
            <Col className="d-flex justify-content-center py-4">
              <input className="btn btn-primary" type="submit" name="accion" />
            </Col>
          </form>
        </section>
      </Row>
    </div>
  );
};
