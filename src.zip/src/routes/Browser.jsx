import { HashRouter, Route, Routes } from "react-router-dom";
import { Login } from "../pages/auth/Login";
import { UsersPage } from "../pages/users/UsersPage";
import { Register } from "../pages/users/Register";

export const Browser = () => {
  return (
    <HashRouter>
        <Routes>
            <Route path='/register' Component={Register}/>
            <Route path='/' Component={Login}/>
            <Route path='/user' Component={UsersPage}/>
        </Routes>
    </HashRouter>
  )
}
