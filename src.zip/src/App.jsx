import { Browser } from './routes/Browser'

function App() {

  return (
      <Browser/>
  )
}

export default App
